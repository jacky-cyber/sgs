<?php

session_start();

	
if(configuracion_cms($template)==1){
 include("captcha/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['texto_ingresado']);

  if($valid == true) {
    $captcha_ok = 1;
  }
}else{
	$captcha_ok = 1;
}
 
  
?>
